#include <iostream>

using namespace std;

int main() {
	int x=10;
	int y=25;
	int z=x+y;

	cout<<"Sum of x+y = " << z;
	return 0;
}
